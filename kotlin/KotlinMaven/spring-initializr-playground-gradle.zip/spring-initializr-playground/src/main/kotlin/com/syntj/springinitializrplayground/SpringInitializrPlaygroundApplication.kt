package com.syntj.springinitializrplayground

import org.springframework.boot.autoconfigure.SpringBootApplication
import org.springframework.boot.runApplication

@SpringBootApplication
class SpringInitializrPlaygroundApplication

fun main(args: Array<String>) {
	runApplication<SpringInitializrPlaygroundApplication>(*args)
}
