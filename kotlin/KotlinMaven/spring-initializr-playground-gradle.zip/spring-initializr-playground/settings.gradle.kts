rootProject.name = "spring-initializr-playground"
